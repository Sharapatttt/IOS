//
//  Message.swift
//  Protrips
//
//  Created by mac on 12/18/20.
//


import Foundation

struct Message {
    let sender: String
    let body: String
}
