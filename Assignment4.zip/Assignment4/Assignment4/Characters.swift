//
//  Characters.swift
//  Assignment4
//
//  Created by Магжан Имангазин on 10/6/20.
//  Copyright © 2020 Магжан Имангазин. All rights reserved.
//

import Foundation
import UIKit
import WebKit

struct Characters {
    var name: String?
    var webView: String?
}
