//
//  Protocol.swift
//  Assignment7
//
//  Created by Azamat Sharapat on 11/6/20.
//  Copyright © 2020 Azamat Sharapat All rights reserved.
//

import Foundation
import UIKit

protocol Protocol {
    func changeText(cityTitle: String, placeTitle: String, index: Int)
}
